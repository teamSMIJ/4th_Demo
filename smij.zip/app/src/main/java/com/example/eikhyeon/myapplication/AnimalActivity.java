package com.example.eikhyeon.myapplication;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.provider.MediaStore;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dd.morphingbutton.MorphingButton;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.CalendarMode;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.http.client.ClientProtocolException;

public class AnimalActivity extends BaseActivity {
    static int REQUEST_PICTURE=1;
    static int REQUEST_PHOTO_ALBUM=2;
    static int serverResponseCode = 3;
    private String serverUri = null;
    private String imagePath = null;
    private String animalDate;
    private String animalName;
    private String hHeightString;
    private String hWeightString;
    private String animalWeightString;
    final int DIALOG_DATE=11;
    private Dialog dialog;
    String useridIntentMessage;
    Intent intent;
    private ProgressDialog progressDialog = null;
    private HttpClient httpClient;
    private HttpPost httpPost;
    private HttpResponse httpResponse;


    private DatePicker schedulePicker;
    private EditText scheduleEdit;
    private TextView scheduleView;
    String scheduleRead;
    int scheduleYear;
    int scheduleMonth;
    int scheduleDay;
    String scheduleTotal;
    private MaterialCalendarView materialCalendarView;
    private EditText animalNameEdit;
    private EditText calendarEdit;
    private EditText hHeight;
    private EditText hWeight;
    private EditText animalWeight;
    private CheckBox genderCheckBoxMale;
    private CheckBox genderCheckBoxFemale;
    private ImageView animalPicture;
    private Button camera;
    private Button album;
    private Button dateSelect;
    private TextView animalDateView;
    private TextView imagePathView;
    private int mYear;
    private int mMonth;
    private int mDay;
    private String genderResult;
    private String tempResult;
    private String secondImagePath;
    private int okCount=0;
    private MorphingButton syncInfo;

    private int morphCounter1=1;
    private int morphCounter2=1;
    private int morphCounter3=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("내 반려동물");
        setContentView(R.layout.activity_animal);
        animalDateView = (TextView)findViewById(R.id.animalDateView);
        animalNameEdit = (EditText)findViewById(R.id.animalNameEdit);
        genderCheckBoxMale = (CheckBox)findViewById(R.id.genderCheckBoxMale);
        genderCheckBoxFemale = (CheckBox)findViewById(R.id.genderCheckBoxFemale);
        animalPicture = (ImageView)findViewById(R.id.animalPicture);
        dateSelect = (Button)findViewById(R.id.dateSelect);
        final MorphingButton okAnimalBtn = (MorphingButton)findViewById(R.id.okAnimalBtn);
        syncInfo = (MorphingButton)findViewById(R.id.syncInfo);
        final MorphingButton modifyAnimalBtn = (MorphingButton)findViewById(R.id.modifyAnimalBtn);
        imagePathView = (TextView)findViewById(R.id.imagePathView);
        hHeight = (EditText)findViewById(R.id.hHeight);
        hWeight = (EditText)findViewById(R.id.hWeight);
        animalWeight = (EditText)findViewById(R.id.animalWeightEdit);

        intent=getIntent();
        useridIntentMessage = intent.getStringExtra("idUser");
        imagePathView.setText(useridIntentMessage);

        dateSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(DIALOG_DATE);
            }
        });
        final Calendar calendar= Calendar.getInstance();
        mYear=calendar.get(Calendar.YEAR);
        mMonth=calendar.get(Calendar.MONTH);
        mDay=calendar.get(Calendar.DATE);

        PermissionListener permissionListener=new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                //Toast.makeText(AnimalActivity.this,"권한 허용",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(ArrayList<String> arrayList) {
                Toast.makeText(AnimalActivity.this,"권한 거절",Toast.LENGTH_SHORT).show();

            }
        };
        new TedPermission(this)
                .setPermissionListener(permissionListener)
                .setRationaleMessage("카메라 호출 권한이 필요합니다")
                .setDeniedMessage("거부하면 어플리케이션을 사용하지 못합니다")
                .setPermissions(Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .check();

        /*
        syncInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    onMorphClicked1(syncInfo);
                    tempResult = new receviceAnimalData().execute(useridIntentMessage).get();
                    StringTokenizer tokenizer = new StringTokenizer(tempResult,";");
                    String name = tokenizer.nextToken();
                    String birth = tokenizer.nextToken();
                    String gender = tokenizer.nextToken();
                    String aWeight = tokenizer.nextToken();
                    String hWeight2 = tokenizer.nextToken();
                    String hHeight2 = tokenizer.nextToken();
                    String image = tokenizer.nextToken();

                    StringTokenizer imageTokenizer =new StringTokenizer(image,"<");
                    String realImage = imageTokenizer.nextToken();
                    String dummy = imageTokenizer.nextToken();

                    animalNameEdit.setText(name);
                    animalNameEdit.setEnabled(false);

                    animalDateView.setText(birth);
                    dateSelect.setEnabled(false);

                    if(gender.equals("male")) genderCheckBoxMale.setChecked(true);
                    else if(gender.equals("female")) genderCheckBoxFemale.setChecked(true);
                    genderCheckBoxMale.setEnabled(false);
                    genderCheckBoxFemale.setEnabled(false);

                    animalWeight.setText(aWeight);
                    animalWeight.setEnabled(false);

                    hWeight.setText(hWeight2);
                    hWeight.setEnabled(false);

                    hHeight.setText(hHeight2);
                    hHeight.setEnabled(false);

                    File imageFile = new File(realImage);
                    if(imageFile.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                        animalPicture.setImageBitmap(bitmap);
                    }
                    else if(image==null) animalPicture.setImageResource(R.drawable.error_error);
                    //여기다가 이미지 위치 설정
                    animalPicture.setEnabled(false);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        */

        okAnimalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMorphClicked2(okAnimalBtn);
                okCount++;
                animalNameEdit.setEnabled(false);
                genderCheckBoxMale.setEnabled(false);
                genderCheckBoxFemale.setEnabled(false);
                animalPicture.setEnabled(false);
                dateSelect.setEnabled(false);
                hWeight.setEnabled(false);
                hHeight.setEnabled(false);
                animalWeight.setEnabled(false);


                animalDate = animalDateView.getText().toString();
                animalName = animalNameEdit.getText().toString();
                if (genderCheckBoxMale.isChecked()) genderResult = "male";
                else if (genderCheckBoxFemale.isChecked()) genderResult = "female";
                hWeightString = hWeight.getText().toString();
                hHeightString = hHeight.getText().toString();
                animalWeightString = animalWeight.getText().toString();

                progressDialog = ProgressDialog.show(AnimalActivity.this,"","정보를 저장중...",true);
                if(okCount==1) {
                    sendToUserId(useridIntentMessage,imagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
                }
                else if(okCount>1) {
                    sendToUserId(useridIntentMessage,secondImagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
                }
                //uploadFile(imagePath);
        /*
        new Thread(new Runnable() {
            @Override
            public void run() {
                sendToUserId(useridIntentMessage,imagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
                uploadFile(imagePath);
            }
        }).start();
        */
            }
        });

        modifyAnimalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMorphClicked3(modifyAnimalBtn);

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        animalNameEdit.setEnabled(true);
                        genderCheckBoxMale.setEnabled(true);
                        genderCheckBoxFemale.setEnabled(true);
                        animalPicture.setEnabled(true);
                        dateSelect.setEnabled(true);
                        hWeight.setEnabled(true);
                        hHeight.setEnabled(true);
                        animalWeight.setEnabled(true);
                    }},2000);
            }
        });



        morphToSquare1(syncInfo, 0);
        morphToSquare2(okAnimalBtn,0);
        morphToSquare3(modifyAnimalBtn,0);
    }

    private void onMorphClicked1(final MorphingButton m) {
        if(morphCounter1==1){

            morphCounter1=0;
            morphToSync(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter1++;
                    morphToSquare1(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }
    private void onMorphClicked2(final MorphingButton m) {
        if(morphCounter2==1){

            morphCounter2=0;
            morphToSuccess(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter2++;
                    morphToSquare2(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }
    private void onMorphClicked3(final MorphingButton m) {
        if(morphCounter3==1){

            morphCounter3=0;
            morphToModify(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter3++;
                    morphToSquare3(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }

    private void morphToSquare1(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_370))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_sync));
        btnMorph.morph(square);
    }

    private void morphToSquare2(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_180))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_ok));
        btnMorph.morph(square);
    }
    private void morphToSquare3(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_180))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_modify));
        btnMorph.morph(square);
    }

    private void morphToSync(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_green))
                .colorPressed(color(R.color.mb_green_dark))
                .icon(R.drawable.sync);
        btnMorph.morph(circle);
    }

    private void morphToSuccess(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_green))
                .colorPressed(color(R.color.mb_green_dark))
                .icon(R.drawable.checker2);
        btnMorph.morph(circle);
    }

    private void morphToModify(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.econg_modify))
                .colorPressed(color(R.color.econg_modifyClicked))
                .icon(R.drawable.fix);
        btnMorph.morph(circle);
    }


    private void updateDate() {
        String str=mYear+"-"+(mMonth+1)+"-"+mDay;
        animalDateView.setText(str);
    }
    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int y, int m, int d) {
            mYear=y;
            mMonth=m;
            mDay=d;
            updateDate();
        }
    };
    protected Dialog  onCreateDialog(int id) {
        switch (id) {
            case DIALOG_DATE:
                return new DatePickerDialog(this,dateSetListener,mYear,mMonth,mDay);
        }
        return null;
    }


    public void okOnClick(View view) {
        okCount++;
        animalNameEdit.setEnabled(false);
        genderCheckBoxMale.setEnabled(false);
        genderCheckBoxFemale.setEnabled(false);
        animalPicture.setEnabled(false);
        dateSelect.setEnabled(false);
        hWeight.setEnabled(false);
        hHeight.setEnabled(false);
        animalWeight.setEnabled(false);


        animalDate = animalDateView.getText().toString();
        animalName = animalNameEdit.getText().toString();
        if (genderCheckBoxMale.isChecked()) genderResult = "male";
        else if (genderCheckBoxFemale.isChecked()) genderResult = "female";
        hWeightString = hWeight.getText().toString();
        hHeightString = hHeight.getText().toString();
        animalWeightString = animalWeight.getText().toString();

        progressDialog = ProgressDialog.show(AnimalActivity.this,"","정보를 저장중...",true);
        if(okCount==1) {
            sendToUserId(useridIntentMessage,imagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
        }
        else if(okCount>1) {
            sendToUserId(useridIntentMessage,secondImagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
        }
        //uploadFile(imagePath);

        /*
        new Thread(new Runnable() {
            @Override
            public void run() {
                sendToUserId(useridIntentMessage,imagePath,animalName,animalDate,genderResult,animalWeightString,hWeightString,hHeightString);
                uploadFile(imagePath);
            }
        }).start();
        */

    }
    public void modifyOnClick(View view) {
        animalNameEdit.setEnabled(true);
        genderCheckBoxMale.setEnabled(true);
        genderCheckBoxFemale.setEnabled(true);
        animalPicture.setEnabled(true);
        dateSelect.setEnabled(true);
        hWeight.setEnabled(true);
        hHeight.setEnabled(true);
        animalWeight.setEnabled(true);
    }


    public void syncOnClick(View view) {





        /*
        try {
            tempResult = new receviceAnimalData().execute(useridIntentMessage).get();
            Toast.makeText(getApplicationContext(),tempResult,Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        */

        try {
            onMorphClicked1(syncInfo);
            tempResult = new receviceAnimalData().execute(useridIntentMessage).get();

            StringTokenizer tokenizer = new StringTokenizer(tempResult,";");
            String dogName = tokenizer.nextToken();
            String dogBirth = tokenizer.nextToken();
            String dogGender = tokenizer.nextToken();
            String dogWeight = tokenizer.nextToken();
            String humanWeight = tokenizer.nextToken();
            String humanHeight = tokenizer.nextToken();
            String dogRoot = tokenizer.nextToken();

            animalNameEdit.setText(dogName);
            animalNameEdit.setEnabled(false);

            animalDateView.setText(dogBirth);
            dateSelect.setEnabled(false);

            if(dogGender.equals("male")) genderCheckBoxMale.setChecked(true);
            else if(dogGender.equals("female")) genderCheckBoxFemale.setChecked(true);
            genderCheckBoxMale.setEnabled(false);
            genderCheckBoxFemale.setEnabled(false);

            animalWeight.setText(dogWeight);
            animalWeight.setEnabled(false);

            hWeight.setText(humanWeight);
            hWeight.setEnabled(false);

            hHeight.setText(humanHeight);
            hHeight.setEnabled(false);

            File imageFile = new File(dogRoot);
            if(imageFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                animalPicture.setImageBitmap(bitmap);
            }
            else if(dogRoot==null) animalPicture.setImageResource(R.drawable.error_error);
            //여기다가 이미지 위치 설정
            animalPicture.setEnabled(false);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void selectPicture(View view) {
        if (view.getId() == R.id.animalPicture) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            View customLayout = View.inflate(this, R.layout.animalselectdialog, null);
            builder.setView(customLayout);
            album = (Button) customLayout.findViewById(R.id.photoAlbum);
            dialog = builder.create();
            dialog.show();
            album.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                    photoAlbum();
                }
            });
        }
    }


        void photoAlbum() {
            Intent intent=new Intent(Intent.ACTION_PICK);
            intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
            intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent,REQUEST_PHOTO_ALBUM);
        }

        protected void onActivityResult(int requestCode,int resultCode , Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (resultCode == RESULT_OK) {
                if (requestCode == REQUEST_PHOTO_ALBUM) {
                    animalPicture.setImageURI(data.getData());
                    Uri selectedImageUri = data.getData();
                    imagePath = getPath(selectedImageUri);
                    secondImagePath = imagePath;
                    Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
                    animalPicture.setImageBitmap(bitmap);
                }
            }
        }
    public String getPath(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery(uri,projection,null,null,null);
        startManagingCursor(cursor);
        int colum_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(colum_index);
    }


    private void sendToUserId(String userId, String imagePath, String animalName, String animalDate , String animalGender, String animalWeight, String hWeight, String hHeight) {
        class sendPost extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                String id = params[0];
                String image = params[1];
                String name = params[2];
                String date = params[3];
                String gender = params[4];
                String aWeight = params[5];
                String hWeight = params[6];
                String hHeight = params[7];
                httpClient = getThreadSafeClient();

                httpPost = new HttpPost("http://smij.dothome.co.kr/Image_controller.php");
                //httpPost = new HttpPost("http://52.78.186.198/Image_controller.php");


                BasicNameValuePair userId = new BasicNameValuePair("userId", id);
                BasicNameValuePair imagePath = new BasicNameValuePair("imagePath", image);
                BasicNameValuePair animalName = new BasicNameValuePair("animalName",name);
                BasicNameValuePair animalDate = new BasicNameValuePair("animalDate",date);
                BasicNameValuePair animalGender = new BasicNameValuePair("animalGender",gender);
                BasicNameValuePair animalWeight = new BasicNameValuePair("animalWeight",aWeight);
                BasicNameValuePair humanWeight = new BasicNameValuePair("humanWeight",hWeight);
                BasicNameValuePair humanHeight = new BasicNameValuePair("humanHeight",hHeight);
                List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
                nameValuePairList.add(userId);
                nameValuePairList.add(imagePath);
                nameValuePairList.add(animalName);
                nameValuePairList.add(animalDate);
                nameValuePairList.add(animalGender);
                nameValuePairList.add(animalWeight);
                nameValuePairList.add(humanWeight);
                nameValuePairList.add(humanHeight);
                try {
                    UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairList, "UTF-8");
                    httpPost.setEntity(urlEncodedFormEntity);
                    try {
                        httpResponse = httpClient.execute(httpPost);
                        InputStream inputStream = httpResponse.getEntity().getContent();
                        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        StringBuilder stringBuilder = new StringBuilder();
                        String buffered = null;
                        while ((buffered = bufferedReader.readLine()) != null) {
                            stringBuilder.append(buffered);
                        }
                        Log.w("서버메시지=", stringBuilder.toString());
                        return stringBuilder.toString();
                    }catch (ClientProtocolException e1) {
                        Log.v("TAG", "First Exception caz of HttpResponese :" + e1);
                        e1.printStackTrace();
                    }catch (IOException e2) {
                        Log.v("TAG", "Second Exception caz of HttpResponse :" + e2);
                        e2.printStackTrace();
                    }
                }catch (UnsupportedEncodingException e3) {
                    Log.v("TAG", "An Exception given because of UrlEncodedFormEntity argument :" + e3);
                    e3.printStackTrace();
                }
                return null;
            }
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                progressDialog.dismiss();
            }
        }
        sendPost sendPost=new sendPost();
        sendPost.execute(userId,imagePath,animalName,animalDate,animalGender,animalWeight,hWeight,hHeight);
    }



    public static DefaultHttpClient getThreadSafeClient()  {

        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }


        class receviceAnimalData extends AsyncTask<String, Void, String> {
            protected void onPreExecute() {}
            @Override
            protected String doInBackground(String... params) {
                try {
                    String userId = params[0];

                    String eikLink="http://smij.dothome.co.kr/Download_controller.php?userId="+userId;
                    String taeLink="http://52.78.186.198/Download_controller.php?userId="+userId;
                    String link = "http://192.168.63.100/ci/index.php/Download_controller?userId="+userId;
                    URL url = new URL(eikLink);
                    HttpClient client = getThreadSafeClient();
                    HttpGet request = new HttpGet();
                    request.setURI(new URI(eikLink));
                    HttpResponse response = client.execute(request);
                    BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    StringBuffer sb = new StringBuffer("");
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } catch (Exception e) {
                    Log.w("Exception = ", e.getMessage());
                }
                return null;
            }

            protected void onPostExecute(String result) {
            }
        }
}
