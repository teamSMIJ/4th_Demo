package com.example.eikhyeon.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.dd.morphingbutton.MorphingButton;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;

public class CAActivity extends Activity {

    Button first,second,third,fourth;
    Intent intent;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ca);

        intent=getIntent();
        userId = intent.getStringExtra("asdasd");
        //Toast.makeText(getApplicationContext(),userId,Toast.LENGTH_SHORT).show();


        first=(Button)findViewById(R.id.firstMapBtn);
        second=(Button)findViewById(R.id.secondMapBtn);
        third=(Button)findViewById(R.id.thirdMapBtn);
        fourth=(Button)findViewById(R.id.fourthMapBtn);


        /*
                startActivity(new Intent(LoginActivity.this,mapTemporaryActivity.class));
                Intent intent = new Intent(LoginActivity.this,mapTemporaryActivity.class);
                intent.putExtra("ddddasd",intentMessage);
                startActivity(intent);
         */



        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String tempRes = new checkLoad().execute(userId).get();
                    if(tempRes.contains("0")){
                        Toast.makeText(getApplicationContext(),"산책로가 없거나 확인 되지 않습니다",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Intent intent =new Intent(CAActivity.this,ZFirstMapActivity.class);
                        intent.putExtra("useridid",userId);
                        startActivity(intent);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });


        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String tempRes =new checkLoad().execute(userId).get();
                    if(tempRes.contains("1") || tempRes.contains("0")) {
                        Toast.makeText(getApplicationContext(),"산책로가 없거나 확인 되지 않습니다",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Intent intent =new Intent(CAActivity.this,ZSecondMapActivity.class);
                        intent.putExtra("useridid",userId);
                        startActivity(intent);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });


        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String tempRes = new checkLoad().execute(userId).get();
                    if(tempRes.contains("2") || tempRes.contains("1") || tempRes.contains("0")) {
                        Toast.makeText(getApplicationContext(),"산책로가 없거나 확인 되지 않습니다",Toast.LENGTH_SHORT).show();
                    }else {
                        Intent intent =new Intent(CAActivity.this,ZThirdMapActivity.class);
                        intent.putExtra("useridid",userId);
                        startActivity(intent);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        fourth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String tempRes = new checkLoad().execute(userId).get();
                    if(tempRes.contains("3") || tempRes.contains("2") || tempRes.contains("1") || tempRes.contains("0")) {
                        Toast.makeText(getApplicationContext(),"산책로가 없거나 확인 되지 않습니다",Toast.LENGTH_SHORT).show();
                    }else {
                        Intent intent =new Intent(CAActivity.this,ZFourthMapActivity.class);
                        intent.putExtra("useridid",userId);
                        startActivity(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }



    class checkLoad extends AsyncTask<String, Void, String> {
        protected void onPreExecute() { }
        @Override
        protected String doInBackground(String... params) {
            try {
                String userId = params[0];

                String eikLink="http://smij.dothome.co.kr/Check_Load.php?userId="+userId;
                String taeLink="http://52.78.186.198/Check_Load.php?userId="+userId;
                String link = "http://192.168.60.38/ci/index.php/Check_Load?userId="+userId;
                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {}
    }



    public static DefaultHttpClient getThreadSafeClient() {
        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }



}
