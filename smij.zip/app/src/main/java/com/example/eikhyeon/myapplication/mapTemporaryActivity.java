package com.example.eikhyeon.myapplication;

import android.Manifest;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.annotation.ColorRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class mapTemporaryActivity extends AppCompatActivity implements OnMapReadyCallback {

    private Button mapStoreBtn;
    private Button mapDeleteBtn;
    private HttpResponse httpResponse;
    private HttpClient httpClient;
    private HttpPost httpPost;
    private static String vib,latlng,colum;
    private static String llat[];
    private static String llng[];
    private static  double doubleLat[]={0,};
    private static  double doubleLng[]={0,};
    private static int intColum;
    private static String arr[];
    private static String serverReceiveMessage;
    private static LatLng[] mapLatLng;
    private String tempResult;
    private String temp;
    Intent intent;
    ProgressDialog progressDialog;
    String useridIntentMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_temporary);
        mapStoreBtn = (Button)findViewById(R.id.mapStoreBtn);
        mapDeleteBtn = (Button)findViewById(R.id.mapDeletBtn);


        intent=getIntent();
        useridIntentMessage = intent.getStringExtra("ddddasd");

        FragmentManager fragmentManager = getFragmentManager();
        final MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Intent intent=getIntent();
        String moduleData = intent.getStringExtra("moduleData");
        //Toast.makeText(getApplicationContext(),moduleData,Toast.LENGTH_SHORT).show();

        PermissionListener permissionListener=new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                //Toast.makeText(mapTemporaryActivity.this,"권한 허용",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(ArrayList<String> arrayList) {
                Toast.makeText(mapTemporaryActivity.this,"권한 거절",Toast.LENGTH_SHORT).show();

            }
        };
        new TedPermission(this)
                .setPermissionListener(permissionListener)
                .setRationaleMessage("맵 허용 권한이 필요합니다")
                .setDeniedMessage("거부하면 어플리케이션을 사용하지 못합니다")
                .setPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
                .check();


        mapStoreBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //insertDB(useridIntentMessage, );
                //StringTokenizer stringTokenizer=new StringTokenizer(tempResult,"<");
                //String real=stringTokenizer.nextToken();
                //String dummy=stringTokenizer.nextToken();

                try {
                    insertDB(useridIntentMessage,tempResult);
                    receiveResponse(useridIntentMessage);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        mapDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String delete="delete";
                deleteSign(delete);
                //Toast.makeText(getApplicationContext(),delete,Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void receiveResponse(String userId) {
        class countMap extends AsyncTask<String, Void, String> {

            protected void onPreExecute() {
            }

            @Override
            protected String doInBackground(String... params) {
                try {
                    String userId = params[0];

                    String eikLink="http://smij.dothome.co.kr/Countmap_controller.php?userId="+userId;
                    String taeLink ="http://52.78.186.198/Countmap_controller.php?userId="+userId;
                    String link = "http://192.168.60.38/ci/index.php/Countmap_controller?userId="+userId;

                    URL url = new URL(eikLink);
                    HttpClient client = getThreadSafeClient();
                    HttpGet request = new HttpGet();
                    request.setURI(new URI(eikLink));
                    HttpResponse response = client.execute(request);
                    BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    StringBuffer sb = new StringBuffer("");
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } catch (Exception e) {
                    Log.w("Exception = ", e.getMessage());
                }
                return null;
            }

            protected void onPostExecute(String result) {
                if(result.contains("4")) {
                    Toast.makeText(getApplicationContext(),"저장되었습니다 현재 맵은 4개입니다.\n 더이상 추가는 되지 않습니다",Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(),"맵이 저장되었어요! 현재 맵은 "+result+"개 입니다 최대 4개까지 저장 가능해요",Toast.LENGTH_SHORT).show();
                }
            }
        }
        countMap countMap =new countMap();
        countMap.execute(userId);
    }

    public void onMapReady(final GoogleMap map) {
        LatLng KPU = new LatLng(37.3396415,126.73474959999998);
        MarkerOptions markerOptions =new MarkerOptions();
        markerOptions.position(KPU);
        markerOptions.title("KPU");
        markerOptions.snippet("컴퓨터공학과");
        map.addMarker(markerOptions);
        map.moveCamera(CameraUpdateFactory.newLatLng(KPU));
        map.animateCamera(CameraUpdateFactory.zoomTo(15));

        try {
            tempResult = new receviceModule().execute().get();
            serverReceiveMessage = tempResult;
            StringTokenizer tokenizer = new StringTokenizer(tempResult, "_");
            vib = tokenizer.nextToken(); //맨앞 진동수
            colum = tokenizer.nextToken(); // 컬럼수
            latlng = tokenizer.nextToken(); // 그다음 latlng값 , <이후값

            intColum = Integer.parseInt(colum);

            arr = latlng.split(";"); // &와 ;이 섞인 latlng를 ;로 나누면 &만 있음

            llat = new String[intColum]; //lat을 담을 배열
            llng = new String[intColum]; //lng를 담을 배열
            doubleLat = new double[intColum]; //lat을 형변환 해서 담을 배열
            doubleLng = new double[intColum]; //lng를 형변환 해서 담을 배열
            for (int i = 0; i < intColum; i++) {
                StringTokenizer stringTokenizer = new StringTokenizer(arr[i], "&"); //latlng를 &로 나누면 lat 랑 lng랑 분리
                llat[i] = stringTokenizer.nextToken();
                llng[i] = stringTokenizer.nextToken();
                doubleLat[i] = Double.parseDouble(llat[i]);
                doubleLng[i] = Double.parseDouble(llng[i]);
            }
            for(int k=0; k<intColum; k++) {

                markerOptions=new MarkerOptions();
                markerOptions.position(new LatLng(doubleLat[k],doubleLng[k]));
                map.addMarker(markerOptions);
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        /*
        MarkerOptions markerOptions=new MarkerOptions();
        markerOptions.position(new LatLng(doubleLat[0],doubleLng[0]));
        map.addMarker(markerOptions);
        */
        /*
        for(int k=0; k<intColum; k++) {
            //mapLatLng = new LatLng[k];
            MarkerOptions markerOptions=new MarkerOptions();
            markerOptions.position(new LatLng(doubleLat[0],doubleLng[0]));
            map.addMarker(markerOptions);
        }
        */
        /*
        LatLng startL=new LatLng(37.341643,126.732299);
        LatLng endL = new LatLng(37.340317,126.734688);
        polylineOptions.add(startL).add(endL).width(15).color(Color.BLACK).geodesic(true);
        map.addPolyline(polylineOptions);
        */
    }

    public static DefaultHttpClient getThreadSafeClient()  {

        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }

    class receviceModule extends AsyncTask<String, Void, String> {
        protected void onPreExecute() {
        }
        @Override
        protected String doInBackground(String... params) {
            try {

                String eikLink="http://smij.dothome.co.kr/ModuleDataDownload_controller.php";
                String taeLink ="http://52.78.186.198/ModuleDataDownload_controller.php";
                String link = "http://192.168.60.38/ci/index.php/ModuleDataDownload_controller";

                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
            }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {
        }
    }



    private void deleteSign(String asd) {
        class dataDeleteSign extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(mapTemporaryActivity.this, "Please Wait", null, true, true);
            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),"삭제되었습니다", Toast.LENGTH_SHORT).show();
            }
            protected String doInBackground(String... params) {
                try {
                    String deleteSign = (String) params[0];


                    String eikLink="http://smij.dothome.co.kr/ModuleDataDelete_controller.php";
                    String taeLink ="http://52.78.186.198/ModuleDataDelete_controller.php";
                    String link = "http://192.168.60.38/ci/index.php/ModuleDataDelete_controller";

                    String data = URLEncoder.encode("ddeleteSSign", "UTF-8") + "=" + URLEncoder.encode(deleteSign, "UTF-8");
                    //data += "&" + URLEncoder.encode("ppw", "UTF-8") + "=" + URLEncoder.encode(ppw, "UTF-8");

                    URL url = new URL(eikLink);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());


                    writer.write(data);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String(e.getMessage());
                }
            }
        }
        dataDeleteSign task=new dataDeleteSign();
        task.execute(asd);
    }

    private void insertDB(String id,String load) {
        class insertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(mapTemporaryActivity.this, "Please Wait", null, true, true);
            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                //Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();
            }

            protected String doInBackground(String... params) {
                try {
                    String iid = (String) params[0];
                    String lload = (String) params[1];


                    String eikLink="http://smij.dothome.co.kr/Storeload_controller.php";
                    String taeLink ="http://52.78.186.198/Storeload_controller.php";
                    String link = "http://192.168.60.38/ci/index.php/Storeload_controller";

                    String data = URLEncoder.encode("iid", "UTF-8") + "=" + URLEncoder.encode(iid, "UTF-8");
                    data += "&" + URLEncoder.encode("lload", "UTF-8") + "=" + URLEncoder.encode(lload, "UTF-8");

                    URL url = new URL(eikLink);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());


                    writer.write(data);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String(e.getMessage());
                }
            }
        }
        insertData task=new insertData();
        task.execute(id,load);
    }
}
