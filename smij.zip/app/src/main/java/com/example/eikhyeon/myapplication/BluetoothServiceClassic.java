package com.example.eikhyeon.myapplication;

import android.content.Context;

/**
 * Created by eikhyeon on 2018-01-24.
 */

public class BluetoothServiceClassic {

    public void initialize(Context context){

    }
}
