package com.example.eikhyeon.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

/**
 * Created by eikhyeon on 2018-01-26.
 */

public class myActionBar extends LinearLayout{

    public myActionBar(Context context) {
        super(context);
        init();
    }

    public myActionBar(Context context, AttributeSet attrs) {
        super(context,attrs);
        init();
    }

    private void init() {
        LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.myactionbar, this, true);
    }
}
