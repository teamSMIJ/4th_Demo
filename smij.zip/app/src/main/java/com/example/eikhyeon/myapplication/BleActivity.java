package com.example.eikhyeon.myapplication;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;


public class BleActivity extends AppCompatActivity implements BluetoothServiceCallback, View.OnClickListener, OnMapReadyCallback {

    private String team="SMIJ";
    private String moduleData;
    private Button receiveButton;
    private MarkerOptions clickMarker;
    private double lat = 0;
    private double lon = 0;

    private static final String TAG = BleActivity.class.getSimpleName();

    //블루투스 연결 요청 식별자
        private static final int REQUEST_BT_ENABLE = 1;

    private BluetoothAdapter rssiAdapter = BluetoothAdapter.getDefaultAdapter();

    //검색 유효시간 10초
    private static final long SCAN_PERIOD = 10000;

    //비동기 UI처리 핸들러
    private Handler mHandler;

    //블루투스 장치검색 다이얼로그뷰
    private Dialog mScanDialog;
    private LinearLayout mDialogScanningLabel;
    private TextView mDialogScanEnable;
    private ListView mScannedDeviceList;
    private ScannedDeviceListAdapter mScannedDeviceListAdapter;

    //블루투스 서비스
    private BluetoothService mBluetoothService;

    //검색된 블루투스 장치 리스트
    private static List<ScannedDevice> mDeviceScanned = new ArrayList<ScannedDevice>();

    //선택된 디바이스 식별자 (주소)
    private String mSelectedDeviceAddress;

    //블루투스 수신 데이터 버퍼
    private byte[] remained =null;

    // 채팅 뷰
    private ListView mChatListView;
    private MessageListAdapter mChatListAdapter;
    private EditText mMessage;
    private ImageView ivActionBarIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble);
        setTitle("블루투스 페어링 연결");
        //registerReceiver(receiver,new IntentFilter(BluetoothDevice.ACTION_FOUND));



        FragmentManager fragmentManager = getFragmentManager();
        final MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.bleMap);
        mapFragment.getMapAsync(this);

        receiveButton = (Button)findViewById(R.id.dataReceiveBtn);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("블루투스 사용법")
                .setMessage("1 : 목소리 녹음하기"+"\n2 : 목소리 출력"+"\n3 : 정지"+"\n4 : GPS"+"\n5 : 진동값");
        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();


        mHandler = new Handler();
        mBluetoothService = BluetoothServiceFactory.getService(BluetoothServiceFactory.BT_LOW_ENERGY);
        mBluetoothService.setServiceCallback(this);
        mMessage=(EditText)findViewById(R.id.etMessage);
        ivActionBarIcon = (ImageView)findViewById(R.id.ivActionBarIcon);


        mChatListView = (ListView)findViewById(R.id.lvMessageList);
        mChatListAdapter = new MessageListAdapter(this);
        mChatListView.setAdapter(mChatListAdapter);

        ivActionBarIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rssiAdapter.startDiscovery();
            }
        });

        PermissionListener permissionListener=new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                //Toast.makeText(BleActivity.this,"권한 허용",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(ArrayList<String> arrayList) {
                Toast.makeText(BleActivity.this,"권한 거절",Toast.LENGTH_SHORT).show();

            }
        };
        new TedPermission(this)
                .setPermissionListener(permissionListener)
                .setRationaleMessage("근처에 있는 블루투스 기기 검색을 위해 위치권한이 필요합니다")
                .setDeniedMessage("거부하면 어플리케이션을 사용하지 못합니다")
                .setPermissions(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
                .check();
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver(){
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            if(BluetoothDevice.ACTION_FOUND.equals(action)) {
                int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
                String name = intent.getStringExtra(BluetoothDevice.EXTRA_NAME);

                NotificationManager notificationManager = (NotificationManager)BleActivity.this.getSystemService(BleActivity.this.NOTIFICATION_SERVICE);
                Intent intent1 = new Intent(BleActivity.this.getApplicationContext(),BleActivity.class);

                Notification.Builder builder = new Notification.Builder(getApplicationContext());
                intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP| Intent.FLAG_ACTIVITY_CLEAR_TOP);
                PendingIntent pendingIntent = PendingIntent.getActivity(BleActivity.this,0,intent1,PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setSmallIcon(R.drawable.asdasd)
                        .setTicker("찾아줄개")
                        .setContentTitle("SMIJ_notification")
                        .setContentText("단말기와 거리가 너무 멉니다!")
                        .setWhen(System.currentTimeMillis());

                if((rssi<=-70)&&(name.contains("SM"))) {
                    notificationManager.notify(1,builder.build());
                }


                /*
                AlertDialog.Builder builder = new AlertDialog.Builder(BleActivity.this);
                builder.setTitle("RSSI distance");
                builder.setMessage(name +"   =   "+rssi);


                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) { }
                });
                builder.show();
                */
            }
        }
    };

    private void showScanDialog() {
        dismissScanDialog();
        clearDevices();

        mScanDialog = new Dialog(this, R.style.lightbox_dialog);
        mScanDialog.setContentView(R.layout.view_scan_dialog);

        mDialogScanningLabel = (LinearLayout)mScanDialog.findViewById(R.id.llDialogScanning);
        mScannedDeviceList = (ListView)mScanDialog.findViewById(R.id.lvScannedDeviceList);
        mScannedDeviceListAdapter = new ScannedDeviceListAdapter(this, mDeviceScanned);

        mDialogScanEnable = (TextView)mScanDialog.findViewById(R.id.tvDialogScanEnable);
        mDialogScanEnable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDialogScanEnable.getText().equals("중지")) {
                    doDeviceScanning(false);
                } else {
                    doDeviceScanning(true);
                }
            }
        });

        mScannedDeviceList.setAdapter(mScannedDeviceListAdapter);

        // 블루투스 장치 검색 다이얼로그에서 검색된 블루투스 장치에 대한 클릭 이벤트 설정
        mScannedDeviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ScannedDevice item = mDeviceScanned.get(position);
                if (item.getState() == ScannedDevice.DEVICE_CONNECTED) {
                    item.setState(ScannedDevice.DEVICE_DISCONNECT);
                    mBluetoothService.disconnect(item.getAddress());
                    mScannedDeviceListAdapter.changeItemState(view, item.getState());

                } else if (item.getState() == ScannedDevice.DEVICE_WAITING) {
                    item.setState(ScannedDevice.DEVICE_CONNECT);
                    mBluetoothService.connect(item.getAddress());
                    mScannedDeviceListAdapter.changeItemState(view, item.getState());
                }
            }
        });

        mScanDialog.show();

        bluetoothInitialize();
    }
    public void dismissScanDialog() {
        mBluetoothService.stopScan();
        if (mScanDialog != null) {
            mScanDialog.dismiss();
        }
        mScannedDeviceList = null;
        mScannedDeviceListAdapter = null;
        mScanDialog = null;
    }

    public void clearDevices() {
        for (int i = mDeviceScanned.size() - 1 ; i >= 0 ; i--) {
            ScannedDevice device = mDeviceScanned.get(i);
            if (!mBluetoothService.isConnected(device.getAddress())) {
                mDeviceScanned.remove(i);
                mBluetoothService.delDeviceScanned(device.getAddress());
            }
        }
    }
    public void deviceConnected(final int position) {
        final ScannedDevice item = mDeviceScanned.get(position);
        item.setState(ScannedDevice.DEVICE_CONNECTED);
        displayLocalMessage(item.getAddress(), "Connected.");
        mSelectedDeviceAddress = item.getAddress();
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mScannedDeviceListAdapter.changeItemState(getView(position), item.getState());
                dismissScanDialog();
            }
        });
    }
    public void deviceDisconnected(final int position) {
        final ScannedDevice item = mDeviceScanned.get(position);
        item.setState(ScannedDevice.DEVICE_WAITING);
        displayLocalMessage(item.getAddress(), "Disconnected.");
        mSelectedDeviceAddress = null;
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mScannedDeviceListAdapter.changeItemState(getView(position), item.getState());
            }
        });
    }
    private void showMessage(String txt) {
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show();
    }

    private View getView(int position) {
        View v = null;
        int firstListItemPosition = mScannedDeviceList.getFirstVisiblePosition();
        int lastListItemPosition = firstListItemPosition + mScannedDeviceList.getChildCount() - 1;
        if (position < firstListItemPosition || position > lastListItemPosition ) {
            v = mScannedDeviceList.getAdapter().getView(position, null, mScannedDeviceList);
        } else {
            final int childIndex = position - firstListItemPosition;
            v = mScannedDeviceList.getChildAt(childIndex);
        }
        return v;
    }

    @Override
    protected void onResume() {
        mBluetoothService.setServiceCallback(this);
        clearDevices();
        super.onResume();
    }

    @Override
    protected void onPause() {
        if (mBluetoothService != null) {
            mBluetoothService.stopScan();
        }
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        if (mBluetoothService != null) {
            mBluetoothService.release();
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {

        // 연결 버튼 클릭 시
        if(v.getId() == R.id.tvActionbarBtnRight) {
            showScanDialog();

            // 메시지 입력 창의 전송 버튼 클릭 시
        } else if (v.getId() == R.id.llSendBtnLayout || v.getId() == R.id.ivSendBtn) {
            if (mSelectedDeviceAddress != null) {
                String txt = mMessage.getText().toString().trim();
                if (!txt.equals("")) {
                    // 메시지의 크기가 20byte 보다 크면 20byte 씩 나눠보낸다.
                    int msgLen = txt.length();
                    int msgCount = msgLen / 20 + ((msgLen % 20 > 0) ? 1 : 0);
                    for (int i = 0 ; i < msgCount ; i++) {
                        int stx = i * 20;
                        int etx = stx + 20;
                        if (i == msgCount - 1) {
                            etx = msgLen;
                        }
                        String data = txt.substring(stx, etx);

                        // 메시지를 전송한다.
                        boolean succ = mBluetoothService.sendData(mSelectedDeviceAddress, data.getBytes());

                        // 뷰에 메시지의 상태를 표시한다.
                        Message msg = new Message();
                        msg.setType(Message.MSG_OUT);
                        msg.setData(data);
                        msg.setStatus((succ) ? Message.STATUS_SUCC : Message.STATUS_FAIL);
                        messageUpdateToListView(msg);
                        mMessage.setText("");
                    }
                }
            } else {
                showMessage("연결된 장치가 없습니다.");
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (mScanDialog != null) {
            dismissScanDialog();
        }
        super.onBackPressed();
    }

    /**
     * 블루투스 기능이 Off되어 있다면 On 시킨다.
     */
    private void bluetoothInitialize() {
        if (!mBluetoothService.initialize(this)) {
            dismissScanDialog();
            Intent enableBLEIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBLEIntent, REQUEST_BT_ENABLE);

        } else {
            doDeviceScanning(true);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 블루투스 기능 On되었다면, 장치를 검색한다.
        if (requestCode == REQUEST_BT_ENABLE) {
            if (resultCode == RESULT_OK) {
                showScanDialog();
            }
        }
    }

    /**
     * 블루투스 장치를 검색하거나 중단한다.
     * @param b
     */
    public void doDeviceScanning(boolean b) {
        if (b) {
            clearDevices();
            mBluetoothService.startScan();
            mDialogScanEnable.setText("중지");
            mDialogScanningLabel.setVisibility(View.VISIBLE);
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mBluetoothService.stopScan();
                    mDialogScanningLabel.setVisibility(View.GONE);
                    mDialogScanEnable.setText("검색");
                }
            }, SCAN_PERIOD);

        } else {
            mBluetoothService.stopScan();
            mDialogScanningLabel.setVisibility(View.GONE);
            mDialogScanEnable.setText("검색");
        }
    }

    /*
     * 검색된 블루투스 장치에 대한 콜백 메소드
     * @param address
     */
    @Override
    public void onScanResult(String address) {
        if (mScanDialog != null) {
            mDeviceScanned.add(new ScannedDevice(address, mBluetoothService.getDeviceName(address)));
            mScannedDeviceListAdapter.notifyDataSetInvalidated();
        } else {
            mBluetoothService.stopScan();
        }
    }

    /**
     * 검색된 장치의 연결 상태에 대한 콜백 메소드
     */
    @Override
    public void onConnectionStateChange(String address, boolean isConnected) {
        for (int i = 0 ; i < mDeviceScanned.size() ; i++) {
            ScannedDevice device = mDeviceScanned.get(i);
            Log.d(TAG, "compare " + device.getAddress() + " vs " + address);
            if (device.getAddress().equals(address)) {
                if (isConnected) {
                    if (i != 0) {
                        mDeviceScanned.remove(i);
                        mDeviceScanned.add(0, device);
                    }
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            mScannedDeviceListAdapter.notifyDataSetInvalidated();
                            deviceConnected(0);
                        }
                    });
                    Log.d(TAG, "connected " + device.getName());

                } else {
                    if (i != mDeviceScanned.size() -1) {
                        mDeviceScanned.remove(i);
                        mDeviceScanned.add(device);
                    }
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mScanDialog != null) {
                                mScannedDeviceListAdapter.notifyDataSetInvalidated();
                                deviceDisconnected(mDeviceScanned.size() - 1);
                            }
                        }
                    });
                    Log.d(TAG, "disconnected " + device.getName());
                }
                break;
            }
        }
    }

    /**
     * 사용자 지정 메시지를 표시한다.
     * @param address
     * @param msg
     */
    public void displayLocalMessage(String address, String msg) {
        onDataRead(address, msg.getBytes());
    }

    @Override
    public void onDataRead(String address, byte[] data) {
        Message msg = new Message();
        msg.setType(Message.MSG_IN);
        msg.setData(new String(data).trim());
        msg.setFrom(mBluetoothService.getDeviceName(address));
        messageUpdateToListView(msg);


    }

    private void insertDB(String moduleData) {
        class insertData extends AsyncTask<String, Void, String> {
            protected void onPreExecute() {
                super.onPreExecute();
            }
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
            }
            protected String doInBackground(String... params) {
                try {
                    String moduleData = (String) params[0];

                    String eikLink="http://smij.dothome.co.kr/Module_controller.php";
                    String taeLink="http://52.78.186.198/Module_controller.php";
                    String link = "http://192.168.60.38/ci/index.php/Module_controller";
                    String data = URLEncoder.encode("moduleData", "UTF-8") + "=" + URLEncoder.encode(moduleData, "UTF-8");

                    URL url = new URL(eikLink);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());


                    writer.write(data);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String(e.getMessage());
                }
            }
        }
        insertData task=new insertData();
        task.execute(moduleData);
    }

    /**
     * 수신된 메시지를 채팅 메시지 리스트 뷰에 반영한다.
     * @param msg
     */
    private void messageUpdateToListView(Message msg) {
        mChatListAdapter.addItem(msg);
        moduleData =msg.getData();
        insertDB(moduleData);

        mChatListView.post(new Runnable() {
            @Override
            public void run() {
                mChatListView.setSelection(mChatListAdapter.getCount() - 1);
            }
        });
    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {
        LatLng KPU = new LatLng(37.3396415,126.73474959999998);
        final MarkerOptions markerOptions =new MarkerOptions();
        markerOptions.position(KPU);
        markerOptions.title("KPU");
        markerOptions.snippet("컴퓨터공학과");
        googleMap.addMarker(markerOptions);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(KPU));
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(15));


        receiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getApplicationContext(),moduleData,Toast.LENGTH_SHORT).show();
                StringTokenizer tokenizer = new StringTokenizer(moduleData,";");
                String latitude=tokenizer.nextToken();
                String longitude=tokenizer.nextToken();


                lat = Double.parseDouble(latitude);
                lon = Double.parseDouble(longitude);


                clickMarker=new MarkerOptions();
                clickMarker.position(new LatLng(lat,lon));
                googleMap.addMarker(clickMarker);


            }
        });



    }






}
