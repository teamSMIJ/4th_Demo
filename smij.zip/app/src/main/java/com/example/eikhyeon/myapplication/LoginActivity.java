package com.example.eikhyeon.myapplication;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.example.eikhyeon.myapplication.Schedule.ScheduleActivity;

public class LoginActivity extends Activity {
    Button animalBtn;
    Button bleBtn;
    Button mapTemp;
    Button courseANDactive;
    String intentMessage;
    Intent intent;
    LottieAnimationView bleLottieAnimationView;
    LottieAnimationView animalLottieAnimationView;
    LottieAnimationView mapLottieAnimationView;
    LottieAnimationView courseLottieAnimationView;
    LottieAnimationView scheduleLottieAnimationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);

        intent=getIntent();
        intentMessage = intent.getStringExtra("userId");
        //Toast.makeText(getApplicationContext(),intentMessage,Toast.LENGTH_SHORT).show();

        bleLottieAnimationView = (LottieAnimationView)findViewById(R.id.bleLottie);
        animalLottieAnimationView=(LottieAnimationView) findViewById(R.id.animalLottie);
        mapLottieAnimationView= (LottieAnimationView) findViewById(R.id.mapLottie);
        courseLottieAnimationView = (LottieAnimationView)findViewById(R.id.courseLottie);
        scheduleLottieAnimationView = (LottieAnimationView)findViewById(R.id.scheduleLottie);


        animalLottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, AnimalActivity.class);
                intent.putExtra("idUser",intentMessage);
                startActivity(intent);
            }
        });


        bleLottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(LoginActivity.this,BleActivity.class);
                startActivity(intent2);

            }
        });

        mapLottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,mapTemporaryActivity.class);
                intent.putExtra("ddddasd",intentMessage);
                startActivity(intent);
            }
        });
        courseLottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this,CAActivity.class);
                intent.putExtra("asdasd",intentMessage);
                startActivity(intent);
            }
        });
        scheduleLottieAnimationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this, ScheduleActivity.class);
                startActivity(intent);
            }
        });

    }

    public BluetoothAdapter.LeScanCallback leScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bytes) {
            Toast.makeText(getApplicationContext(),bluetoothDevice.getName()+" "+i,Toast.LENGTH_SHORT).show();

        }
    };
}
