package com.example.eikhyeon.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.dd.morphingbutton.MorphingButton;

public class TempTemp extends AppCompatActivity {

    MorphingButton tempBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_temp);
    }
}
